// Lazy loading utilities for performance optimization
export * from "@/components/loading/loading-spinner";